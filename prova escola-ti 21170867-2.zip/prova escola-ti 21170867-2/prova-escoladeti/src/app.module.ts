import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { VeiculoModule } from './veiculo/veiculo.module';
import { MongooseModule } from '@nestjs/mongoose';
import { AcessorioModule } from './acessorio/acessorio.module';

@Module({
  imports: [VeiculoModule, MongooseModule.forRoot('mongodb://0.0.0.0/nest'), AcessorioModule], //mongodb://0.0.0.0/nest
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
