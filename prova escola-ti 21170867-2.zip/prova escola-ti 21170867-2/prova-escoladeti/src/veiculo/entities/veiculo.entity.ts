import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Types } from 'mongoose';

export type VeiculoDocument = HydratedDocument<Veiculo>;

@Schema()
export class Veiculo {
  @Prop()
  modelo: string;

  @Prop()
  anoFabricacao: number;

  @Prop()
  placa: string;

  @Prop({ type: [{ type: Types.ObjectId, ref: 'Acessorio' }] })
  acessorios: Types.ObjectId[]; // Array de IDs de acessórios
}

export const VeiculoSchema = SchemaFactory.createForClass(Veiculo);
