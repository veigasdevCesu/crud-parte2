import { Module } from '@nestjs/common';
import { VeiculoService } from './veiculo.service';
import { VeiculoController } from './veiculo.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Veiculo, VeiculoSchema } from './entities/veiculo.entity';

@Module({
  controllers: [VeiculoController],
  providers: [VeiculoService],
  imports: [MongooseModule.forFeature([{ name: Veiculo.name, schema: VeiculoSchema }])]
})
export class VeiculoModule {}
