import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateVeiculoDto } from './dto/create-veiculo.dto';
import { UpdateVeiculoDto } from './dto/update-veiculo.dto';
import { Veiculo } from './entities/veiculo.entity';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { Acessorio } from 'src/acessorio/entities/acessorio.entity';

@Injectable()
export class VeiculoService {
  constructor(@InjectModel(Veiculo.name) private veiculoModel: Model<Veiculo>) {}

  async create(createVeiculoDto: CreateVeiculoDto): Promise<Veiculo> {
    const createdVeiculo = new this.veiculoModel(createVeiculoDto)
    return createdVeiculo.save()
  }

  async findAll(): Promise<Veiculo[]>  {
    return this.veiculoModel.find().exec()
  }

  async findOne(id: string): Promise<Veiculo> {
    const veiculo = await this.veiculoModel.findById(id).exec();  // Buscar pelo _id

    if (!veiculo) {
      throw new NotFoundException(`Veículo com ID ${id} não encontrado`);
    }

    return veiculo;
  }

  async update(id: string, updateVeiculoDto: UpdateVeiculoDto): Promise<Veiculo> {
    const veiculoAtualizado = await this.veiculoModel
      .findByIdAndUpdate(id, updateVeiculoDto, { new: true })  // 'new: true' retorna o objeto atualizado
      .exec();
  
    if (!veiculoAtualizado) {
      throw new NotFoundException(`Veículo com ID ${id} não encontrado`);
    }
  
    return veiculoAtualizado;
  }
  

  async remove(id: string): Promise<Veiculo> {
    const veiculoRemovido = await this.veiculoModel.findByIdAndDelete(id).exec();  // Remover pelo _id
  
    if (!veiculoRemovido) {
      throw new NotFoundException(`Veículo com ID ${id} não encontrado`);
    }
  
    return veiculoRemovido;
  }
  

  async adicionarAcessorio(veiculoId: string, acessorioId: string): Promise<Veiculo> {
    return this.veiculoModel.findByIdAndUpdate(
      veiculoId,
      { $push: { acessorios: acessorioId } }, 
      { new: true }, 
    ).exec();
  }

  async removerAcessorio(veiculoId: string, acessorioId: string): Promise<Veiculo> {
    return this.veiculoModel.findByIdAndUpdate(
      veiculoId,
      { $pull: { acessorios: acessorioId } }, 
      { new: true }, 
    ).exec();
    }

}
