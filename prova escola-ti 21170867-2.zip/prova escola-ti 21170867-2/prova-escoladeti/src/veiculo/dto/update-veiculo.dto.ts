import { Types } from "mongoose";

export class UpdateVeiculoDto {

    modelo: String;

    anoFabricacao: Number;

    placa: String;

    acessorios?: Types.ObjectId[];

}
