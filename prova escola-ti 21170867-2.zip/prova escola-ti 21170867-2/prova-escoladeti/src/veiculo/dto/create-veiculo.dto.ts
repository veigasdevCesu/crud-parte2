import { Types } from "mongoose";

export class CreateVeiculoDto {

    modelo: String;

    anoFabricacao: Number;

    placa: String;

    acessorios?: Types.ObjectId[];

}
