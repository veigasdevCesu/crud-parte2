import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateAcessorioDto } from './dto/create-acessorio.dto';
import { UpdateAcessorioDto } from './dto/update-acessorio.dto';
import { Acessorio } from './entities/acessorio.entity';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class AcessorioService {
  constructor(@InjectModel(Acessorio.name) private acessorioModel: Model<Acessorio>) {}

  async create(createAcessorioDto: CreateAcessorioDto): Promise<Acessorio> {
    const createdAcessorio = new this.acessorioModel(createAcessorioDto)
    return createdAcessorio.save()
  }

  async findAll(): Promise<Acessorio[]>  {
    return this.acessorioModel.find().exec()
  }

  async findOne(id: string): Promise<Acessorio> {
    const veiculo = await this.acessorioModel.findById(id).exec();  // Buscar pelo _id

    if (!veiculo) {
      throw new NotFoundException(`Veículo com ID ${id} não encontrado`);
    }

    return veiculo;
  }

  async update(id: string, updateVeiculoDto: UpdateAcessorioDto): Promise<Acessorio> {
    const veiculoAtualizado = await this.acessorioModel
      .findByIdAndUpdate(id, updateVeiculoDto, { new: true })  // 'new: true' retorna o objeto atualizado
      .exec();
  
    if (!veiculoAtualizado) {
      throw new NotFoundException(`Veículo com ID ${id} não encontrado`);
    }
  
    return veiculoAtualizado;
  }

  async remove(id: string): Promise<Acessorio> {
    const veiculoRemovido = await this.acessorioModel.findByIdAndDelete(id).exec();  // Remover pelo _id
  
    if (!veiculoRemovido) {
      throw new NotFoundException(`Veículo com ID ${id} não encontrado`);
    }
  
    return veiculoRemovido;
  }
}