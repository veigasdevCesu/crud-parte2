export class UpdateAcessorioDto {

    nome: String;

}
