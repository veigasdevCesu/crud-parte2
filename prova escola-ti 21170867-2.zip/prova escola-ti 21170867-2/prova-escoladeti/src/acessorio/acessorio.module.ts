import { Module } from '@nestjs/common';
import { AcessorioService } from './acessorio.service';
import { AcessorioController } from './acessorio.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Acessorio, AcessorioSchema } from './entities/acessorio.entity';

@Module({
  controllers: [AcessorioController],
  providers: [AcessorioService],
  imports: [MongooseModule.forFeature([{ name: Acessorio.name, schema: AcessorioSchema }])]
})
export class AcessorioModule {}
