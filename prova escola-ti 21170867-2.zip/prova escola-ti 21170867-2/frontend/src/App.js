import React, { useState } from 'react';
import './App.css'; // Arquivo CSS que será criado

// Componente principal da aplicação
function App() {
  const [currentPage, setCurrentPage] = useState('home'); // Estado para controlar a página atual
  const [vehicleData, setVehicleData] = useState({ id: '', modelo: '', anoFabricacao: '', placa: '' }); // Dados do veículo
  const [accessoryData, setAccessoryData] = useState({ id: '', nome: '' }); // Dados do acessório
  const [searchedVehicle, setSearchedVehicle] = useState(null); // Dados do veículo buscado
  const [searchedAccessory, setSearchedAccessory] = useState(null); // Dados do acessório buscado

  // Função para renderizar a tela inicial com botões de veículos e acessórios
  const renderHomePage = () => (
    <div className="container">
      <h1>Bem-vindo</h1>
      <div className="button-container">
        <button onClick={() => setCurrentPage('veiculos')}>Veículos</button>
        <button onClick={() => setCurrentPage('acessorios')}>Acessórios</button>
      </div>
    </div>
  );

  // Função para renderizar o menu de ações para veículos
  const renderVehiclePage = () => (
    <div className="container">
      <h2>Gestão de Veículos</h2>
      <div className="button-container">
        <button onClick={() => setCurrentPage('criarVeiculo')}>Criar Veículo</button>
        <button onClick={() => setCurrentPage('procurarVeiculo')}>Procurar um Veículo</button>
        <button onClick={() => setCurrentPage('procurarTodosVeiculos')}>Procurar Todos os Veículos</button>
        <button onClick={() => setCurrentPage('atualizarVeiculo')}>Atualizar Veículo</button>
        <button onClick={() => setCurrentPage('deletarVeiculo')}>Deletar Veículo</button>
        <button onClick={() => setCurrentPage('home')}>Voltar</button>
      </div>
    </div>
  );

  // Função para renderizar o menu de ações para acessórios
  const renderAccessoryPage = () => (
    <div className="container">
      <h2>Gestão de Acessórios</h2>
      <div className="button-container">
        <button onClick={() => setCurrentPage('criarAcessorio')}>Criar Acessório</button>
        <button onClick={() => setCurrentPage('procurarAcessorio')}>Procurar um Acessório</button>
        <button onClick={() => setCurrentPage('procurarTodosAcessorios')}>Procurar Todos os Acessórios</button>
        <button onClick={() => setCurrentPage('atualizarAcessorio')}>Atualizar Acessório</button>
        <button onClick={() => setCurrentPage('deletarAcessorio')}>Deletar Acessório</button>
        <button onClick={() => setCurrentPage('home')}>Voltar</button>
      </div>
    </div>
  );

  // Página de criar veículo
  const renderCreateVehiclePage = () => (
    <div className="container">
      <h2>Criar Veículo</h2>
      <input
        type="text"
        placeholder="Modelo"
        value={vehicleData.modelo}
        onChange={(e) => setVehicleData({ ...vehicleData, modelo: e.target.value })}
      />
      <input
        type="number"
        placeholder="Ano de Fabricação"
        value={vehicleData.anoFabricacao}
        onChange={(e) => setVehicleData({ ...vehicleData, anoFabricacao: e.target.value })}
      />
      <input
        type="text"
        placeholder="Placa"
        value={vehicleData.placa}
        onChange={(e) => setVehicleData({ ...vehicleData, placa: e.target.value })}
      />
      <div className="button-container">
        <button onClick={() => alert('Veículo criado!')}>Criar</button>
        <button onClick={() => setCurrentPage('veiculos')}>Voltar</button>
      </div>
    </div>
  );

  // Página de procurar um veículo
  const renderFindVehiclePage = () => (
    <div className="container">
      <h2>Procurar Veículo</h2>
      <input
        type="text"
        placeholder="ID do Veículo"
        onChange={(e) => setSearchedVehicle({ id: e.target.value })}
      />
      <div className="button-container">
        <button onClick={() => alert('Veículo encontrado!')}>Procurar</button>
        <button onClick={() => setCurrentPage('veiculos')}>Voltar</button>
      </div>
    </div>
  );

  // Página de procurar todos os veículos
  const renderFindAllVehiclesPage = () => (
    <div className="container">
      <h2>Procurar Todos os Veículos</h2>
      <div className="button-container">
        <button onClick={() => alert('Todos os veículos listados!')}>Listar Todos</button>
        <button onClick={() => setCurrentPage('veiculos')}>Voltar</button>
      </div>
    </div>
  );

  // Página de deletar um veículo
  const renderDeleteVehiclePage = () => (
    <div className="container">
      <h2>Deletar Veículo</h2>
      <input
        type="text"
        placeholder="ID do Veículo"
        onChange={(e) => setSearchedVehicle({ id: e.target.value })}
      />
      <div className="button-container">
        <button onClick={() => alert('Veículo deletado!')}>Deletar</button>
        <button onClick={() => setCurrentPage('veiculos')}>Voltar</button>
      </div>
    </div>
  );

  // Página de atualizar um veículo
  const renderUpdateVehiclePage = () => (
    <div className="container">
      <h2>Atualizar Veículo</h2>
      <input
        type="text"
        placeholder="ID do Veículo"
        value={vehicleData.id}
        onChange={(e) => setVehicleData({ ...vehicleData, id: e.target.value })}
      />
      <input
        type="text"
        placeholder="Modelo"
        value={vehicleData.modelo}
        onChange={(e) => setVehicleData({ ...vehicleData, modelo: e.target.value })}
      />
      <input
        type="number"
        placeholder="Ano de Fabricação"
        value={vehicleData.anoFabricacao}
        onChange={(e) => setVehicleData({ ...vehicleData, anoFabricacao: e.target.value })}
      />
      <input
        type="text"
        placeholder="Placa"
        value={vehicleData.placa}
        onChange={(e) => setVehicleData({ ...vehicleData, placa: e.target.value })}
      />
      <div className="button-container">
        <button onClick={() => alert('Veículo atualizado!')}>Atualizar</button>
        <button onClick={() => setCurrentPage('veiculos')}>Voltar</button>
      </div>
    </div>
  );

  // Página de criar acessório
  const renderCreateAccessoryPage = () => (
    <div className="container">
      <h2>Criar Acessório</h2>
      <input
        type="text"
        placeholder="Nome do Acessório"
        value={accessoryData.nome}
        onChange={(e) => setAccessoryData({ ...accessoryData, nome: e.target.value })}
      />
      <div className="button-container">
        <button onClick={() => alert('Acessório criado!')}>Criar</button>
        <button onClick={() => setCurrentPage('acessorios')}>Voltar</button>
      </div>
    </div>
  );

  // Página de procurar um acessório
  const renderFindAccessoryPage = () => (
    <div className="container">
      <h2>Procurar Acessório</h2>
      <input
        type="text"
        placeholder="ID do Acessório"
        onChange={(e) => setSearchedAccessory({ id: e.target.value })}
      />
      <div className="button-container">
        <button onClick={() => alert('Acessório encontrado!')}>Procurar</button>
        <button onClick={() => setCurrentPage('acessorios')}>Voltar</button>
      </div>
    </div>
  );

  // Página de procurar todos os acessórios
  const renderFindAllAccessoriesPage = () => (
    <div className="container">
      <h2>Procurar Todos os Acessórios</h2>
      <div className="button-container">
        <button onClick={() => alert('Todos os acessórios listados!')}>Listar Todos</button>
        <button onClick={() => setCurrentPage('acessorios')}>Voltar</button>
      </div>
    </div>
  );

  // Página de deletar um acessório
  const renderDeleteAccessoryPage = () => (
    <div className="container">
      <h2>Deletar Acessório</h2>
      <input
        type="text"
        placeholder="ID do Acessório"
        onChange={(e) => setSearchedAccessory({ id: e.target.value })}
      />
      <div className="button-container">
        <button onClick={() => alert('Acessório deletado!')}>Deletar</button>
        <button onClick={() => setCurrentPage('acessorios')}>Voltar</button>
      </div>
    </div>
  );

  // Página de atualizar um acessório
  const renderUpdateAccessoryPage = () => (
    <div className="container">
      <h2>Atualizar Acessório</h2>
      <input
        type="text"
        placeholder="ID do Acessório"
        value={accessoryData.id}
        onChange={(e) => setAccessoryData({ ...accessoryData, id: e.target.value })}
      />
      <input
        type="text"
        placeholder="Nome do Acessório"
        value={accessoryData.nome}
        onChange={(e) => setAccessoryData({ ...accessoryData, nome: e.target.value })}
      />
      <div className="button-container">
        <button onClick={() => alert('Acessório atualizado!')}>Atualizar</button>
        <button onClick={() => setCurrentPage('acessorios')}>Voltar</button>
      </div>
    </div>
  );

  // Função para renderizar a página atual com base no estado
  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'veiculos':
        return renderVehiclePage();
      case 'acessorios':
        return renderAccessoryPage();
      case 'criarVeiculo':
        return renderCreateVehiclePage();
      case 'procurarVeiculo':
        return renderFindVehiclePage();
      case 'procurarTodosVeiculos':
        return renderFindAllVehiclesPage();
      case 'atualizarVeiculo':
        return renderUpdateVehiclePage();
      case 'deletarVeiculo':
        return renderDeleteVehiclePage();
      case 'criarAcessorio':
        return renderCreateAccessoryPage();
      case 'procurarAcessorio':
        return renderFindAccessoryPage();
      case 'procurarTodosAcessorios':
        return renderFindAllAccessoriesPage();
      case 'atualizarAcessorio':
        return renderUpdateAccessoryPage();
      case 'deletarAcessorio':
        return renderDeleteAccessoryPage();
      default:
        return renderHomePage();
    }
  };

  return <div className="App">{renderCurrentPage()}</div>;
}

export default App;
