import axios from 'axios';

// URL base da API do backend
const API_URL = 'http://localhost:3000'; // Ajuste conforme necessário

// Funções para Veículo
export const criarVeiculo = (veiculoData) => {
  return axios.post(`${API_URL}/veiculo`, veiculoData);
};

export const buscarVeiculo = (id) => {
  return axios.get(`${API_URL}/veiculo/${id}`);
};

export const buscarTodosVeiculos = () => {
  return axios.get(`${API_URL}/veiculo`);
};

export const atualizarVeiculo = (id, veiculoData) => {
  return axios.patch(`${API_URL}/veiculo/${id}`, veiculoData);
};

export const deletarVeiculo = (id) => {
  return axios.delete(`${API_URL}/veiculo/${id}`);
};

// Funções para Acessório
export const criarAcessorio = (acessorioData) => {
  return axios.post(`${API_URL}/acessorio`, acessorioData);
};

export const buscarAcessorio = (id) => {
  return axios.get(`${API_URL}/acessorio/${id}`);
};

export const buscarTodosAcessorios = () => {
  return axios.get(`${API_URL}/acessorio`);
};

export const atualizarAcessorio = (id, acessorioData) => {
  return axios.patch(`${API_URL}/acessorio/${id}`, acessorioData);
};

export const deletarAcessorio = (id) => {
  return axios.delete(`${API_URL}/acessorio/${id}`);
};
